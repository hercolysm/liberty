<?php
/**
* Exemplo de código Index
* @author Name  <email>
*/

class Index_Controller extends Lb_Controllers{
    	public function init(){
	}
        public function index(){}
}
?>
