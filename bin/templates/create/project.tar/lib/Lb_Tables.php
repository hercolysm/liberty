<?php
/**
 * Classe de constantes editaveis pelo lb.php
 * @author Lucas Brito <lucas@libertynet.com.br>
 */
class Lb_Tables{
 
}